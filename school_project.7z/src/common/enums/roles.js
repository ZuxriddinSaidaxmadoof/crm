export const roles = {
  ADMIN: "admin",
  STUDENT: "student",
  TEACHER: "teacher",
  PARENT: "parent",
};
